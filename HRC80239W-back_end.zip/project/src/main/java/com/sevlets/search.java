package com.sevlets;
import jakarta.servlet.ServletException; 


import com.google.gson.Gson; 
import java.sql.ResultSet; 
import java.sql.Statement; 
import java.sql.Connection; 
import java.sql.SQLException; 
import java.io.IOException; 
import com.google.gson.GsonBuilder; 
import com.highradius.jdbc; 
 
import java.util.ArrayList; 
import jakarta.servlet.http.HttpServletResponse; 
import jakarta.servlet.http.HttpServletRequest; 
import jakarta.servlet.annotation.WebServlet; 
import jakarta.servlet.http.HttpServlet; 
import pojo.file; 
@WebServlet({ "/SearchInvoice" }) 
public class search extends HttpServlet { 
 private static final long serialVersionUID = 1L; 
  protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException { 
         try { 
           Connection con = jdbc.initializeDatabase(); 
             final String searchInvoice = request.getParameter("cust_number"); 
             final Statement st = con.createStatement(); 
             //query for search
             final String sql_statement = "SELECT * FROM winter_internship WHERE cust_number ='" + searchInvoice + "'"; 
             final ResultSet rs = st.executeQuery(sql_statement); 
             final ArrayList<file> data = new ArrayList<file>(); 
             while (rs.next()) { 
                 final file inv = new file(); 
                  
               
                 data.add(inv); 
             } 
             final Gson gson = new GsonBuilder().serializeNulls().create(); 
             final String invoices = gson.toJson((Object)data); 
             response.setContentType("application/json"); 
             try { 
                 response.getWriter().write(invoices); 
             } 
             catch (IOException e) { 
                 e.printStackTrace(); 
             } 
             rs.close(); 
             st.close(); 
             con.close(); 
         } 
         catch (SQLException e2) { 
             e2.printStackTrace(); 
         } 
         catch (Exception e3) { 
             e3.printStackTrace(); 
         } 
     } 
      
     protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException { 
         this.doGet(request, response); 
     } 
 }