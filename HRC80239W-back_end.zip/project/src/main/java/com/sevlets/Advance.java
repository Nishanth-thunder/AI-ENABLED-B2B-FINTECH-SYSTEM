package com.sevlets;



import java.io.IOException;


 
import java.io.PrintWriter; 
import java.sql.Connection; 
import java.sql.DriverManager; 
import java.sql.PreparedStatement; 
import java.sql.ResultSet; 
import java.sql.SQLException; 
import java.sql.Statement; 
import java.util.ArrayList; 

import javax.servlet.ServletException; 
import javax.servlet.annotation.WebServlet; 
import javax.servlet.http.HttpServlet; 
import javax.servlet.http.HttpServletRequest; 
import javax.servlet.http.HttpServletResponse; 
 
import com.google.gson.Gson; 
import com.google.gson.GsonBuilder;
import com.highradius.jdbc; 
import com.sevlets.*; 

import pojo.file; 

@WebServlet("/Adv") 
public class Advance extends HttpServlet { 
 private static final long serialVersionUID = 1L; 
        
    
    public Advance() { 
        super(); 
     
    } 
 
 
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 

  response.setContentType("text/html"); 
  PrintWriter pw=response.getWriter(); 
  int invoice_id=Integer.parseInt(request.getParameter("invoice_id")); 
  String doc_id = request.getParameter("doc_id"); 
  int cust_number = Integer.parseInt(request.getParameter("cust_number")); 
  String buisness_year = request.getParameter("buisness_year"); 
  System.out.println(invoice_id); 
 
   
  try { 
   Class.forName("com.mysql.cj.jdbc.Driver"); 
   Connection con = jdbc.initializeDatabase(); 
   Statement st =con.createStatement(); 
   //query for rs
   ResultSet rs =st.executeQuery("select * from winter_internship where doc_id="+doc_id+" AND "+"invoice_id="+invoice_id+" OR "+"cust_number = "+cust_number+" AND "+"buisness_year = "+buisness_year); 
    
   ArrayList<file> data = new ArrayList<>(); 
   while(rs.next()) { 
    file inv = new file(); 
    inv.setDoc_id(rs.getString("doc_id")); 
    inv.setInvoice_id(rs.getInt("invoice_id")); 
    inv.setCust_number(rs.getInt("cust_number")); 
 
    inv.setBuisness_year(rs.getInt("buisness_year")); 
 
     
     
    data.add(inv); 
   } 
 //gson to json
   Gson gson = new GsonBuilder().serializeNulls().create(); 
   String invoices  = gson.toJson(data); 
   response.setContentType("application/json"); 
   try { 
    response.getWriter().write(invoices); 
   } 
   catch(IOException e) 
   { 
    e.printStackTrace(); 
   } 
   rs.close(); 
   st.close(); 
   con.close(); 
  }catch (ClassNotFoundException e) { 
  
   e.printStackTrace(); 
  }catch (SQLException e) { 

   e.printStackTrace(); 
  } 
   
 } 
 
 
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 
 
   doGet(request, response); 
  } 
 
 }
