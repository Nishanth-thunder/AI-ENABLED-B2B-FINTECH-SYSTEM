package com.sevlets;

import java.io.IOException;

 


import java.util.ArrayList; 
 
import com.google.gson.*; 
import com.sevlets.*; 
 
import pojo.file; 
 
 
import jakarta.servlet.ServletException; 
import jakarta.servlet.annotation.WebServlet; 
import jakarta.servlet.http.HttpServlet; 
import jakarta.servlet.http.HttpServletRequest; 
import jakarta.servlet.http.HttpServletResponse; 
 
@WebServlet("/fetch") 
 
public class fetch extends HttpServlet{ 
 private static final long serialVersionUID = 1L; 
     
     
    public fetch() { 
        super(); 
       
    } 
 
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 
  
   crud fetchdata=new crud(); 
    
    ArrayList<file> data = fetchdata.getData(); 
    //gson to json
      
     Gson gson = new Gson(); 
   String respData = gson.toJson(data); 
    
   response.getWriter().print(respData); 
 } 
 
 
 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 

 } 
 
}