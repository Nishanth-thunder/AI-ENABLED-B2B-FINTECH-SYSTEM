package com.highradius;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class jdbc {
 public static Connection initializeDatabase()

     throws SQLException, ClassNotFoundException
 {
     
     String dbDriver = "com.mysql.cj.jdbc.Driver";
     String dbURL = "jdbc:mysql:// localhost:3306/";
     //Giving authorization credentials for database
     String dbName = "grey_goose";
     String dbUsername = "root";
     String dbPassword = "Nish@123";

     Class.forName(dbDriver);
     Connection con = DriverManager.getConnection(dbURL + dbName,
                                                  dbUsername, 
                                                  dbPassword);
    //generating connection
     return con;
 }
 

public static void main(String[] args) {
}
}



